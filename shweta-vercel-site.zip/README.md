# Shweta — Law, Rights & Perspective

A responsive, static editorial MVP for Shweta's legal knowledge publication. The site is built with plain HTML, CSS and JavaScript so it can be deployed directly on Vercel without a build step.

## Deploy to Vercel

1. Put the contents of this folder in a GitHub repository (or import the folder with Vercel CLI).
2. In Vercel, choose **Add New → Project** and import the repository.
3. Leave the framework preset as **Other**. Set the project root to this folder if the repository contains other files. Leave build and output commands blank; the site is static.
4. Deploy. Vercel will serve `index.html` and the linked assets.
5. Replace `YOUR-DOMAIN.example` in `robots.txt` and `sitemap.xml`, and replace the placeholder social metadata / example content before public launch.

## What's included

- Editorial homepage and responsive mobile navigation
- Curated article cards and client-side category filters
- Casebook previews and topic-based rights entry points
- About Shweta, newsletter presentation, general-information disclaimer
- Search dialog (presentation only; no content index yet)
- Newsletter form interaction (presentation only; no subscriber is stored)
- Basic metadata, robots file, sitemap and Vercel static configuration

## Before launch

The sample essays, case entries, dates and legal topics are illustrative content and must be replaced with fact-checked, cited writing. Update the site domain in metadata, `robots.txt` and `sitemap.xml`. Connect the newsletter form to an email service; add a CMS and structured content store before publishing at scale. Have the disclaimer and other legal policies reviewed for the relevant jurisdiction. This MVP does not provide legal advice, accounts, paid memberships, admin access, analytics, or a working search backend.
